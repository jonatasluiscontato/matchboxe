
# Match Boxe (versão demo)

Este é o site estático do **Match Boxe** — pronto para subir no GitHub Pages.

Conteúdo:
- `index.html` — página principal
- `style.css` — estilos
- `script.js` — interações (match, depósito simulado, apostas)
- `assets/images/` — (opcional) pasta para imagens locais

**Observação:** A funcionalidade de depósito e apostas é **simulada no cliente** (navegador) — não há integração de pagamentos neste envio.

---
